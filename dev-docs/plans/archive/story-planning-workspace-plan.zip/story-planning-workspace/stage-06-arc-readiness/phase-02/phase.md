---
phase: 02
title: "UI readiness"
status: planned
owner: frontend+planner
---

# Phase 02: UI readiness

## Steps
- [ ] Minimal arc metadata display
- [ ] Ensure planner remains calm

## Notes
- Keep UI componentized and typed
- Avoid route-specific shell duplication
