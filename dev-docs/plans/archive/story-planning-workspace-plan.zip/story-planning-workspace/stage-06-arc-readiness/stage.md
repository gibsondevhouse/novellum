---
stage: 06-arc-readiness
title: "Arc readiness (hooks)"
owner: frontend+planner
status: planned
---

# Stage 06-arc-readiness: Arc readiness (hooks)

## Goals
- Prepare data model for arc references without overbuilding
- Add optional tagging hooks for arc progression
- Ensure planner UI can display arc metadata later

## Acceptance Criteria
- Data model accepts arc references
- Minimal UI affordance exists for arc tagging
- Planner does not require redesign to add arcs later

## Deliverables
- stage documentation
- code changes tracked via PR checklist
- evidence folder populated with screenshots / notes
