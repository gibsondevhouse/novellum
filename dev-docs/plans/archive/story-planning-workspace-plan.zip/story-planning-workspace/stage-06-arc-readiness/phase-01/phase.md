---
phase: 01
title: "Arc hooks"
status: planned
owner: frontend+planner
---

# Phase 01: Arc hooks

## Steps
- [ ] Add arc reference support
- [ ] Add optional tagging hooks

## Notes
- Keep UI componentized and typed
- Avoid route-specific shell duplication
