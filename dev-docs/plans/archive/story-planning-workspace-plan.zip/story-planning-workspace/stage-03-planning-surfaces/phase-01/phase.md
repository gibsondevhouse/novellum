---
phase: 01
title: "Planning shell extraction"
status: planned
owner: frontend+planner
---

# Phase 01: Planning shell extraction

## Steps
- [ ] Extract PlanningSurfaceCard primitives
- [ ] Move chapter/scene panels to shared shell

## Notes
- Keep UI componentized and typed
- Avoid route-specific shell duplication
