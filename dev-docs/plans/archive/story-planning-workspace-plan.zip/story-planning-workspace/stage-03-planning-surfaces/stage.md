---
stage: 03-planning-surfaces
title: "Planning surfaces (shell + cards)"
owner: frontend+planner
status: planned
---

# Stage 03-planning-surfaces: Planning surfaces (shell + cards)

## Goals
- Extract reusable PlanningSurface shell and primitives
- Ensure Overview/Outline parity (sizing + layout)
- Ensure internal scroll + sticky header

## Acceptance Criteria
- All planning panels share the same shell
- Overview/Outline parity verified across Chapter/Scene
- Planning card uses internal scroll


## Deliverables
- stage documentation
- code changes tracked via PR checklist
- evidence folder populated with screenshots / notes
