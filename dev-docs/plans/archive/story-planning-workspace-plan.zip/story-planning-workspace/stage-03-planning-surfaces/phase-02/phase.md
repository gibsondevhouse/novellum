---
phase: 02
title: "Overview/Outline parity"
status: planned
owner: frontend+planner
---

# Phase 02: Overview/Outline parity

## Steps
- [ ] Audit sizing/layout parity
- [ ] Fix inconsistent cards

## Notes
- Keep UI componentized and typed
- Avoid route-specific shell duplication
