---
phase: 01
title: "Beat list refactor"
status: planned
owner: frontend+planner
---

# Phase 01: Beat list refactor

## Steps
- [ ] Remove beat titles
- [ ] Numbered beats only

## Notes
- Keep UI componentized and typed
- Avoid route-specific shell duplication
