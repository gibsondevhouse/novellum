---
part: 01
title: "Beat overlay focus management"
status: planned
owner: frontend
---

# Part 01: Beat overlay focus management

## Checklist
- [ ] Prototype in sandbox route or story
- [ ] Implement in module
- [ ] Add acceptance tests
- [ ] Update docs/prompts

## Implementation Notes
Overlay must be narrower/shorter than card. ESC closes and returns focus.
