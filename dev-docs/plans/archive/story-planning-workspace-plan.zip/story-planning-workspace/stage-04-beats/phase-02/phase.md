---
phase: 02
title: "Beat overlay behavior"
status: planned
owner: frontend+planner
---

# Phase 02: Beat overlay behavior

## Steps
- [ ] Implement overlay sizing
- [ ] Add focus management

## Notes
- Keep UI componentized and typed
- Avoid route-specific shell duplication
