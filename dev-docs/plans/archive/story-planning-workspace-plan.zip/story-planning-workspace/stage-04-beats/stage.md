---
stage: 04-beats
title: "Beat model + overlay"
owner: frontend+planner
status: planned
---

# Stage 04-beats: Beat model + overlay

## Goals
- Implement beat list as numbered units (no titles)
- Implement beat focus overlay sized slightly smaller than card
- Share beat components across Chapter/Scene

## Acceptance Criteria
- Beats display as numbered units only
- Beat overlay is narrower/shorter than parent card
- Shared beat list overlay used in Chapter + Scene

## Deliverables
- stage documentation
- code changes tracked via PR checklist
- evidence folder populated with screenshots / notes
