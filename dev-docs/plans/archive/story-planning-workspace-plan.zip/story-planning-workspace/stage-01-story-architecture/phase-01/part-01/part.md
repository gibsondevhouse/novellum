---
part: 01
title: "StoryFrame model"
status: planned
owner: frontend
---

# Part 01: StoryFrame model

## Checklist
- [ ] Prototype in sandbox route or story
- [ ] Implement in module
- [ ] Add acceptance tests
- [ ] Update docs/prompts

## Implementation Notes
Model fields: premise/logline/theme/stakes/promise/notes. Ensure acts/chapter/storyframe do not break editor.
