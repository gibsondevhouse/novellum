---
phase: 01
title: "Story Frame entity + panel"
status: planned
owner: frontend+planner
---

# Phase 01: Story Frame entity + panel

## Steps
- [ ] Add StoryFrame model & persistence
- [ ] Add story-frame planning panel using shared shell

## Notes
- Keep UI componentized and typed
- Avoid route-specific shell duplication
