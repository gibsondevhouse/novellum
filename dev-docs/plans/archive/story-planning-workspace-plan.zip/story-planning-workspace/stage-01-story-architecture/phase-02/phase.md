---
phase: 02
title: "Act entity + panel"
status: planned
owner: frontend+planner
---

# Phase 02: Act entity + panel

## Steps
- [ ] Add Act model & persistence
- [ ] Refactor hierarchy to Act -> Chapter

## Notes
- Keep UI componentized and typed
- Avoid route-specific shell duplication
