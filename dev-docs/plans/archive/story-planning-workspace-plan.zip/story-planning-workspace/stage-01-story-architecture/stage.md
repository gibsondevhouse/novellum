---
stage: 01-story-architecture
title: "Story Frame + Acts"
owner: frontend+planner
status: planned
---

# Stage 01-story-architecture: Story Frame + Acts

## Goals
- Implement story-frame planning entity and UI panel
- Implement act-level planning entity and UI panel
- Assign chapters to acts

## Acceptance Criteria
- Story frame exists and is editable
- Acts exist and are editable
- Chapters belong to acts and render in hierarchy

## Deliverables
- stage documentation
- code changes tracked via PR checklist
- evidence folder populated with screenshots / notes
