---
phase: 02
title: "Surface signals in cards"
status: planned
owner: frontend+planner
---

# Phase 02: Surface signals in cards

## Steps
- [ ] Show pacing summary per act/chapter
- [ ] Highlight missing sections

## Notes
- Keep UI componentized and typed
- Avoid route-specific shell duplication
