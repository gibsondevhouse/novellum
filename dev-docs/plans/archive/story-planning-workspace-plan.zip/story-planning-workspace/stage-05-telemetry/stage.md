---
stage: 05-telemetry
title: "Pacing telemetry"
owner: frontend+planner
status: planned
---

# Stage 05-telemetry: Pacing telemetry

## Goals
- Add basic structural counts (acts/chapters/scenes/beats)
- Add density indicators (thin/overloaded sections)
- Add warnings for missing planning sections

## Acceptance Criteria
- Navigator shows counts
- Planner surfaces display density signal
- Missing planning content surfaced without blocking work

## Deliverables
- stage documentation
- code changes tracked via PR checklist
- evidence folder populated with screenshots / notes
