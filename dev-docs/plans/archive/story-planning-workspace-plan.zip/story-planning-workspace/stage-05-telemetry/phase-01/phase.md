---
phase: 01
title: "Counts + density"
status: planned
owner: frontend+planner
---

# Phase 01: Counts + density

## Steps
- [ ] Add counts to hierarchy entries
- [ ] Add density warnings

## Notes
- Keep UI componentized and typed
- Avoid route-specific shell duplication
