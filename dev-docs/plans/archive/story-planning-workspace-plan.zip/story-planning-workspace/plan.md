---
plan: story-planning-workspace
status: draft
owner: planning-agent
created: 2026-04-12
module: outliner
priority: high
---

# Story Planning Workspace Refactor (Implementation-Ready Plan)

## Intent
Refactor the current Outline page into a cohesive Story Planning Workspace with explicit structure (Story Frame → Acts → Chapters → Scenes → Beats). Ensure the planning surface is reusable across modules (Editor handoff, Story Bible detail cards, Consistency review).

## Scope
- Story Frame (premise/logline/theme/stakes)
- Act structure (Act I/II/III with summaries)
- Navigator hierarchy upgrades (act → chapter → scene)
- Planning surface shell (uniform cards, internal sticky header, internal scroll)
- Beat model (numbers only; beat overlay)
- Pacing telemetry (counts/density)
- Arc readiness hooks (tag references without overbuilding)
- Migration + QA

## Success Criteria
- Story planning hierarchy implemented end-to-end
- Chapter/Scene planning cards are UI-parity and use shared shell
- Overview/Outline parity in size/layout behavior
- Beats use numbers-only model + overlay editor
- Navigator supports Acts
- Planning data model extensible to arcs later
- No bespoke route shells; everything componentized and typed
