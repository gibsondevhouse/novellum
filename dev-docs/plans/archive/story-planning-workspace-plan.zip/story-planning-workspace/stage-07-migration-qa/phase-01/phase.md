---
phase: 01
title: "Migration script"
status: planned
owner: frontend+planner
---

# Phase 01: Migration script

## Steps
- [ ] Migrate outline → planning model
- [ ] Add rollback safeguards

## Notes
- Keep UI componentized and typed
- Avoid route-specific shell duplication
