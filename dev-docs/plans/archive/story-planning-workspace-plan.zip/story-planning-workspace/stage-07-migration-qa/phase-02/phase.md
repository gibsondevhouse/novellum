---
phase: 02
title: "QA + performance"
status: planned
owner: frontend+planner
---

# Phase 02: QA + performance

## Steps
- [ ] Add smoke/e2e checks
- [ ] Performance test large dataset

## Notes
- Keep UI componentized and typed
- Avoid route-specific shell duplication
