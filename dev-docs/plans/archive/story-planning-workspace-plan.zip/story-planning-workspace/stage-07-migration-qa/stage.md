---
stage: 07-migration-qa
title: "Migration + QA"
owner: frontend+planner
status: planned
---

# Stage 07-migration-qa: Migration + QA

## Goals
- Migrate existing outline data to new model safely
- Validate UI with automation + manual smoke tests
- Performance check on large outline data

## Acceptance Criteria
- Migration script runs without data loss
- Tests pass (typecheck, lint, e2e where feasible)
- Planner remains performant

## Deliverables
- stage documentation
- code changes tracked via PR checklist
- evidence folder populated with screenshots / notes
