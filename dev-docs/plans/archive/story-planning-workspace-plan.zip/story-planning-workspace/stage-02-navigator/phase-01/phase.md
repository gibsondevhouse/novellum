---
phase: 01
title: "Hierarchy UI refactor"
status: planned
owner: frontend+planner
---

# Phase 01: Hierarchy UI refactor

## Steps
- [ ] Implement Act/Chapter/Scene tree
- [ ] Introduce calm selector-first interactions

## Notes
- Keep UI componentized and typed
- Avoid route-specific shell duplication
