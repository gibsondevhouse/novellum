---
stage: 02-navigator
title: "Navigator hierarchy & UX"
owner: frontend+planner
status: planned
---

# Stage 02-navigator: Navigator hierarchy & UX

## Goals
- Refactor navigator into calm selector-first panel
- Support act/chapter/scene grouping and expansion
- Strong selected state without excessive controls

## Acceptance Criteria
- Navigator supports acts and nested chapters/scenes
- Selected item is unmistakable
- Utility controls are de-emphasized

## Deliverables
- stage documentation
- code changes tracked via PR checklist
- evidence folder populated with screenshots / notes
