---
phase: 02
title: "Selected state + utility containment"
status: planned
owner: frontend+planner
---

# Phase 02: Selected state + utility containment

## Steps
- [ ] Design selected state system
- [ ] De-emphasize utility controls

## Notes
- Keep UI componentized and typed
- Avoid route-specific shell duplication
